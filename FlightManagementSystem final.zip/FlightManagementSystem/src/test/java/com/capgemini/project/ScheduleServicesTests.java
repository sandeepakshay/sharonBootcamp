package com.capgemini.project;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.project.services.ScheduleServiceImp;

@SpringBootTest
public class ScheduleServicesTests {
	
	
	@Autowired
	ScheduleServiceImp service;
	
	
	@Test
	void  sample() {
		
		 
		
		    
	}
	
	
	
	

}
