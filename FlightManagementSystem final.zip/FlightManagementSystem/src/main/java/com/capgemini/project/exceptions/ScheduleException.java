package com.capgemini.project.exceptions;

public class ScheduleException extends RuntimeException{

	
	private static final long serialVersionUID = 1L;

	public ScheduleException(String msg) {
		
		super(msg);
	}
}
