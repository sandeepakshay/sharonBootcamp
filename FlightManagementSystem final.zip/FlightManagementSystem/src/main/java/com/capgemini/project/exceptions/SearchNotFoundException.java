package com.capgemini.project.exceptions;

public class SearchNotFoundException extends Exception{
	
	
	private static final long serialVersionUID = 1L;

	public SearchNotFoundException(String msg) {
		
		super(msg);
	}

}
